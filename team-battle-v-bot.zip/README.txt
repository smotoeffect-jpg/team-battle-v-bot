
1️⃣ העלה את כל הקבצים האלה למאגר GitHub חדש בשם team-battle-v-bot.
2️⃣ ב-Render, צור New Web Service ובחר את המאגר.
3️⃣ אחרי שהאתר עלה, הפעל את הפקודה הזו ב-Terminal:
curl -F "url=https://team-battle-v-bot.onrender.com/webhook" https://api.telegram.org/bot8366510657:AAEC5for6-8246aKdW6F5w3FPfJ5oWNLCfA/setWebhook
